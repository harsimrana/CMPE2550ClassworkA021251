<?php 
    echo "<p> &copy; Copyright: Simran 2025 </p>";
?>